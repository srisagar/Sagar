import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;


public class Puui {

      public static void main(String[] args) {
            // TODO Auto-generated method stub
      
            File ieExecutable = new File("C:\\Developers\\IEDriverServer.exe");
            System.setProperty("webdriver.ie.driver",
                        ieExecutable.getAbsolutePath());
            DesiredCapabilities capabilitiesIE = DesiredCapabilities
                        .internetExplorer();
            capabilitiesIE
                        .setCapability(
                                    InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
                                    true);
            capabilitiesIE.setCapability("ignoreZoomSetting", true);
            capabilitiesIE.setCapability("nativeEvents", false);
            InternetExplorerDriver driver = new InternetExplorerDriver(capabilitiesIE);
            
            driver.manage().timeouts().implicitlyWait(10,  TimeUnit.SECONDS);
            driver.get("http://dlliquid-cm02:8080/ccpinfo/envstatus.jsp");
            WebElement element = driver.findElement(By.linkText("https://pu-test.fanniemae.com/pricing-utility-ui"));

            
       //     driver.get("http://google.com");

     //       WebElement element = driver.findElement(By.name("q"));

            element.click();
            
          WebElement element1 = driver.findElement(By.name("username"));
          
          element1.sendKeys("g8uvcm");
          
          WebElement element2 = driver.findElement(By.name("password"));

          element2.sendKeys("B#nz2016");
          
            element2.submit();

            System.out.println("Page title is" + driver.getTitle());

      }
      

}
