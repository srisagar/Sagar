package com.fanniemae.stayfit.firstExample;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class StayfitExample {

	public static void main(String[] args) throws InterruptedException {
		
		StayfitExample example = new StayfitExample();
		WebDriver driver = example.getFireFoxWebDriver();
		driver.get("http://52.2.144.221/");
		
		//Enter food information
		example.saveFoodData(driver);
		
		//enter exercise information
		example.saveExerciseDate(driver);
		
		//To avoid stale element exception
		driver.navigate().refresh();
		System.out.println("Refreshing to avoid stale exception while loading report");
		System.out.println("Checking report status");
		//Naviagate to Report tab
		WebElement reportTab = driver.findElement(By.id("reportIcon"));
		reportTab.click();
		
		WebElement reportTableRow = driver.findElement(By.id("reportRow"));
		List<WebElement> data = reportTableRow.findElements(By.tagName("td"));
		String date = data.get(0).getText();
		String caloriesConsumed = data.get(1).getText();
		String caloriesBurnt = data.get(2).getText();
		String netCalories = data.get(3).getText();
		String status = data.get(4).getText();
		System.out.println("Report Status = "  + date + " --- CalaoriesIntake = "  + caloriesConsumed 
				+ ", CalaoriesBurned = "  + caloriesBurnt + ", Health status = " + status);
	}
	
	/**
	 * Get firefox driver
	 * @return
	 */
	public WebDriver getFireFoxWebDriver() {
		WebDriver webdriver = null;
		FirefoxProfile ffProfile = new ProfilesIni().getProfile("default");
		ffProfile.setPreference("signon.autologin.proxy", true);
		webdriver = new FirefoxDriver(ffProfile);
		
		webdriver.manage().timeouts().implicitlyWait(25000L, TimeUnit.MILLISECONDS);
		return webdriver;
	}
	
	/**
	 * Enter and save food data
	 * @param driver
	 */
	public void saveFoodData(final WebDriver driver) {
		System.out.println("Entering food data");
		WebElement foodDateField = driver.findElement(By.id("fooddate[0]"));
		foodDateField.clear();
		foodDateField.sendKeys("2016-08-19");
		
		WebElement foodItem = driver.findElement(By.id("foodItemSel"));
		Select foodItemSelect = new Select(foodItem);
		foodItemSelect.selectByVisibleText("Daal");
		
		WebElement foodQuantity = driver.findElement(By.id("foodQuantSel"));
		Select foodQuantitySelect = new Select(foodQuantity);
		foodQuantitySelect.selectByVisibleText("2");
		
		//Click on the Save button
		WebElement saveFoodElement = driver.findElement(By.id("saveFood"));
		saveFoodElement.click();
		WebElement confirmSave = driver.findElement(By.cssSelector("button[data-bb-handler='confirm']"));
		confirmSave.click();
		WebElement acknowledgeSaved = driver.findElement(By.cssSelector("button[data-bb-handler='ok']"));
		acknowledgeSaved.click();
		System.out.println("Food data entered succesfully");
	}
	
	/**
	 * Enter and save exercise data
	 * @param driver
	 */
	public void saveExerciseDate(final WebDriver driver) {
		System.out.println("Entering Exercise data");

//		Thread.sleep(2000);
//		WebElement exerciseTab = driver.findElement(By.id("exerciseIcon"));
		
		//To avoid stale element exception
		driver.navigate().refresh();
		System.out.println("Refresh done");

		//Navigate to exercise tab
		WebDriverWait waitForExercise = new WebDriverWait(driver,30);
		waitForExercise.until(ExpectedConditions.elementToBeClickable(By.id("exerciseIcon"))).click();
		
		//Enter excercise information
	    WebElement exerciseDate = driver.findElement(By.id("excercisedate[0]"));
		exerciseDate.sendKeys("2016-08-19");
		
		WebElement exerciseItem = driver.findElement(By.id("exerciseItem"));
		Select exerciseType = new Select(exerciseItem);
		exerciseType.selectByVisibleText("Abs");
		
		WebElement exerciseDuration = driver.findElement(By.id("exerciseDuration"));
		Select exerciseDurationSelect = new Select(exerciseDuration);
		exerciseDurationSelect.selectByVisibleText("15");
		
		WebElement saveExercise = driver.findElement(By.xpath(".//*[@id='saveExercise']"));
		saveExercise.click();
		
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement confirmSaveExr = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("button[data-bb-handler='confirm']")));
		
		executor.executeScript("arguments[0].click();", confirmSaveExr);
		WebElement acknowledgeSavedExr = driver.findElement(By.cssSelector("button[data-bb-handler='ok']"));
		executor.executeScript("arguments[0].click();", acknowledgeSavedExr);
		System.out.println("Exercise data entered succesfully");

	}

}
