import java.awt.List;
import java.io.File;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

public class Stayfit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver;
		// System.out.println();
		FirefoxProfile firefoxProfile = new ProfilesIni().getProfile("default");
		firefoxProfile.setPreference("signon.autologin.proxy", true);
		driver = new FirefoxDriver(firefoxProfile);

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://52.2.144.221/");

		// WebElement foodicon =
		// driver.findElement(By.xpath(".//*[@id='foodIcon']"));

		// foodicon.click();

		// WebElement Clrfood =
		// driver.findElement(By.xpath(".//*[@id='clearFood']"));

		// Clrfood.click();

		// Accepts (Click on OK) Chrome Alert Browser for RESET button.
		// driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// driver.findElement(By.xpath("html/body/div[5]/div/div/div[2]/button[2]")).click();

		// Object Repository
		// WebElement dateSelection
		// driver.findElement(By.cssSelector(".btn btn-primary")).click();

		// pop1.click();

		// WebElement pop1 =
		// driver.findElement(By.cssSelector(".btn btn-primary"));

		// pop1.click();

		// btn btn-primary

		// Alert alertOK = driver.switchTo().alert();
		// alertOK.accept();

		// Alert alertOKCon = driver.switchTo().alert();
		// alertOKCon.accept();

		WebElement element1 = driver.findElement(By.id("fooddate[0]"));
		element1.clear();
		element1.sendKeys("2016-08-01");
		
		

		System.out.println(" i am here");
		
		Select foodsItemsId = (Select) driver.findElement(By.xpath(".//*[@id='foodItemSel']"));
		foodsItemsId.selectByValue("number:5");
		System.out.println(" i am here 2");

		Select foodsQty = (Select) driver.findElement(By.id("foodQuantSel"));

		((Select) foodsItemsId).selectByValue("5");

		System.out.println("Page title is" + driver.getTitle());

	}

}
