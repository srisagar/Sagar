import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.server.handler.SendKeys;

/**
 * 
 */

/**
 * @author g8uvcm
 *
 */
public class Gsearch {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver;
		// System.out.println();
		FirefoxProfile firefoxProfile = new ProfilesIni().getProfile("default");
		firefoxProfile.setPreference("signon.autologin.proxy", true);
		driver = new FirefoxDriver(firefoxProfile);

		// driver = new InternetExplorerDriver();

		driver.get("http://www.google.com");

		WebElement element = driver.findElement(By.name("q"));

		element.sendKeys("Fannie");

		element.submit();

		System.out.println("Page title is" + driver.getTitle());

	}

}
