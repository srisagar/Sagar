import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;


public class IEsearch {

      public static void main(String[] args) {
            // TODO Auto-generated method stub
      
            File ieExecutable = new File("C:\\Developers\\IEDriverServer.exe");
            System.setProperty("webdriver.ie.driver",
                        ieExecutable.getAbsolutePath());
            DesiredCapabilities capabilitiesIE = DesiredCapabilities
                        .internetExplorer();
            capabilitiesIE
                        .setCapability(
                                    InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
                                    true);
            capabilitiesIE.setCapability("ignoreZoomSetting", true);
            capabilitiesIE.setCapability("nativeEvents", false);
            InternetExplorerDriver driver = new InternetExplorerDriver(capabilitiesIE);
            
   
     driver.get("http://google.com");

           WebElement element = driver.findElement(By.name("q"));

            element.sendKeys("Fannie");

            element.submit();

            System.out.println("Page title is" + driver.getTitle());

      }
      

}
