package com.fanniemae.stayfit.cucumber.utils;

import static com.fanniemae.testeng.automation.utils.ScenarioUtils.getScenarioName;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

import com.fanniemae.testeng.automation.common.QcTestResult;
import com.fanniemae.testeng.automation.common.ScenarioContext;
import com.fanniemae.testeng.automation.utils.LocalConfUtils;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Common {

    private static final String BUILD_NUMBER = "BUILD_NUMBER";

    @Before(order = 1)
    public void allSetUp(Scenario scenario) {
        ScenarioContext.localConf = LocalConfUtils.loadLocalConf();
        ScenarioContext.scenario.set(scenario);
        String buildNumber = LocalConfUtils.getProperty(BUILD_NUMBER);

        String scenarioNameForFolderCreation = getScenarioName(scenario) + "_" + getFormatedDate("MM-dd-yyyy HH.mm.ss");
        if (!StringUtils.isEmpty(buildNumber)) {
            scenarioNameForFolderCreation = buildNumber + File.separatorChar + scenarioNameForFolderCreation;
        } else {
            // create artifacts in new folder with current timestamp
            scenarioNameForFolderCreation = getFormatedDate("MM-dd-yyyy HH.mm") + File.separatorChar + scenarioNameForFolderCreation;
        }
        System.setProperty(ScenarioContext.SCENARIO_NAME_PROPERTY_NAME, scenarioNameForFolderCreation);
        String resultsDirName = scenarioNameForFolderCreation;
        StayFitConfUtils.setResultsDir(resultsDirName);
    }

    private String getFormatedDate(String dateFormat) {
        Date currentTime = new Date();
        DateFormat df = new SimpleDateFormat(dateFormat);
        String formatedDate = df.format(currentTime);
        return formatedDate;
    }
    

    @After
    public void allTearDown(Scenario scenario) {
      //Added try catch block to safely close the driver
        String scenarioName = ScenarioContext.getScenarioName();
        String scenarioResult = ScenarioContext.scenario.get().getStatus();
        String scenarioResultsDir = StayFitConfUtils.getResultsDir();

        if (scenarioResult.contentEquals("passed")) {
          scenarioResult = "Passed";
        } else {
          scenarioResult = "Failed";
          //Appending timestamp to the failed scenario name
          StayFitConfUtils.appendFailedScenarios(scenarioName+ "\t" + getFormatedDate("MM-dd-yyyy HH.mm"));
        }
        QcTestResult currentQcResult = new QcTestResult(scenarioName, scenarioResult, scenarioResultsDir);
        ScenarioContext.setCurrentQcResult(currentQcResult);
    }

}
