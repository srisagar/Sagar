package com.fanniemae.stayfit.cucumber.utils;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.fanniemae.testeng.automation.common.ScenarioContext;


public class WebElementUtils {
	
	
	public static void waitForElement(WebElement element) {
		WebDriverWait wait = new WebDriverWait(ScenarioContext.webDriver.get(), 10l);
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}
	
	public static void waitForElementToBeVisible(WebElement element) {
		WebDriverWait wait = new WebDriverWait(ScenarioContext.webDriver.get(), 10l);
		wait.until(ExpectedConditions.visibilityOf(element));
	}

}
