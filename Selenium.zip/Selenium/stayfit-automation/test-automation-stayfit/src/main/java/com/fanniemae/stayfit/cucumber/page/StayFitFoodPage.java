package com.fanniemae.stayfit.cucumber.page;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.fanniemae.stayfit.cucumber.page.BasePage;

public class StayFitFoodPage extends BasePage {
	
	@FindBy(id="saveFood")
	public WebElement saveFood;
	
	@FindBy(id="saveExercise")
	public WebElement saveExercise;
	
	@FindBy(id="clearFood")
	public WebElement clearFood;
	
	@FindBy(id="clearExercise")
	public WebElement clearExercise;
	
	@FindBy(id="addButton")
	public WebElement addButton;
	
	@FindBy(id="fooddate[0]")
	public WebElement foodDateField;
	
	@FindBy(id="foodItemSel")
	public WebElement foodItem;
	
	@FindBy(id="foodQuantSel")
	public WebElement foodQuantity;
	
	@FindBy(id="excercisedate[0]")
	public WebElement exerciseDate;
	
	@FindBy(id="exerciseItem")
    public WebElement exerciseItem;
    
    @FindBy(id="exerciseDuration")
    public WebElement exerciseDuration;
    
    @FindBy(id="reportRow")
    public WebElement reportTableRow;
}
