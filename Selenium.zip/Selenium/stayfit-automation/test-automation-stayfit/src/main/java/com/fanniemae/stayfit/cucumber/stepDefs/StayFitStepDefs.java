package com.fanniemae.stayfit.cucumber.stepDefs;

import java.util.List;

import com.fanniemae.stayfit.cucumber.impl.StayFitStepsImpl;
import com.fanniemae.stayfit.cucumber.vo.ExerciseVO;
import com.fanniemae.stayfit.cucumber.vo.FoodVO;
import com.fanniemae.stayfit.cucumber.vo.ReportVO;

import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StayFitStepDefs extends BaseStepDef {
	
	StayFitStepsImpl stayFitStepsImpl = null;
	
	@Before
	public void before() {
		getFireFoxWebDriver();
		getFireFoxWebDriver().get("http:tinyurl.com/stayfit-test");
	}
	
	@Given("^As a \"([^\"]*)\" I want to track my \"([^\"]*)\" habits$")
	public void validateFieldsOfFoodAndExercise(String userGroup, String thing) throws Exception {
		stayFitStepsImpl = new StayFitStepsImpl();
		if("food".equalsIgnoreCase(thing)) {
			stayFitStepsImpl.navigateToFoodTab();
		} else if ("exercise".equalsIgnoreCase(thing)) {
			stayFitStepsImpl.navigateToExerciseTab();
		} else {
			stayFitStepsImpl.navigateToFoodTab();
		}
	}

	@Then("^I should have option to record my food and exercise for a particular date$")
	public void checkFieldsOnFoodAndExerciseTabs() throws Exception {
		stayFitStepsImpl = new StayFitStepsImpl();
		stayFitStepsImpl.checkFieldsOnFoodTab();
		stayFitStepsImpl.navigateToExerciseTab();
		stayFitStepsImpl.checkFieldsOnExerciseTab();
	}

	@When("^I provide the food data and quantity for the corresponding date as :$")
	public void enterFoodInformation(List<FoodVO> foodInformation) throws Exception {
		stayFitStepsImpl = new StayFitStepsImpl();
		stayFitStepsImpl.enterFoodInformation(foodInformation.get(0));
	}

	@When("^I chose to clear the provided \"([^\"]*)\" data$")
	public void clearInformation(String information) throws Exception {
		stayFitStepsImpl = new StayFitStepsImpl();
		if ("food".equalsIgnoreCase(information)) {
			stayFitStepsImpl.clearFoodInformation();	
		} else if ("exercise".equalsIgnoreCase(information)) {
			stayFitStepsImpl.clearExerciseInformation();
		}
		
	}

	@Then("^all my \"([^\"]*)\" data gets deleted$")
	public void validteInformationIsDeleted(String information) throws Exception {
		stayFitStepsImpl = new StayFitStepsImpl();
		if ("food".equalsIgnoreCase(information)) {
			stayFitStepsImpl.validateFoodInformationIsDeleted();
		} else if ("exercise".equalsIgnoreCase(information)) {
			stayFitStepsImpl.validateExerciseInformationIsDeleted();
		}
	}

	@When("^I provide the exercise data and duration for the corresponding date as :$")
	public void enterExerciseInformation(List<ExerciseVO> exercises) throws Exception {
		stayFitStepsImpl = new StayFitStepsImpl();
		stayFitStepsImpl.navigateToExerciseTab();
		stayFitStepsImpl.enterExerciseInformation(exercises.get(0));
	}

	@Then("^I should be able to see my report with following details :$")
	public void validateReport(List<ReportVO> reports) throws Exception {
		stayFitStepsImpl = new StayFitStepsImpl();
		stayFitStepsImpl.validateReport(reports.get(0));
	}
	
	@And("^I choose to save the \"([^\"]*)\" data$")
	public void saveInformation(String information) throws Exception {
		stayFitStepsImpl = new StayFitStepsImpl();
		if ("food".equalsIgnoreCase(information)) {
			stayFitStepsImpl.saveFoodInformation();
		} else if ("exercise".equalsIgnoreCase(information)) {
			stayFitStepsImpl.saveExerciseInformation();
		}
	}

}
