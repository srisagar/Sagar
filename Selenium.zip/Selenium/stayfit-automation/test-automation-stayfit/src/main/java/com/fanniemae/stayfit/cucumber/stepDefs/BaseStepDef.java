package com.fanniemae.stayfit.cucumber.stepDefs;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.internal.ProfilesIni;

import com.fanniemae.testeng.automation.common.ScenarioContext;



public abstract class BaseStepDef {
	
	private static WebDriver webdriver;
		
	public static WebDriver getFireFoxWebDriver() {
		if (webdriver == null) {
			String profileName = System.getProperty("profile");
			if(profileName != null) {
				ProfilesIni profilesini = new ProfilesIni();
				webdriver = new FirefoxDriver(profilesini.getProfile(profileName));
			} else {
				webdriver = new FirefoxDriver();
			}
			webdriver.manage().timeouts().implicitlyWait(3000L, TimeUnit.MILLISECONDS);
			ScenarioContext.webDriver.set(webdriver);
			return webdriver;
		}
		return webdriver;
	}
}
