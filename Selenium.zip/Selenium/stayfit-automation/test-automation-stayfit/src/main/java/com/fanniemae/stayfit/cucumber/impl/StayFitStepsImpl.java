package com.fanniemae.stayfit.cucumber.impl;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.fanniemae.stayfit.cucumber.page.StayFitFoodPage;
import com.fanniemae.stayfit.cucumber.vo.ExerciseVO;
import com.fanniemae.stayfit.cucumber.vo.FoodVO;
import com.fanniemae.stayfit.cucumber.vo.ReportVO;
import com.fanniemae.testeng.automation.common.ScenarioContext;
import com.fanniemae.testeng.automation.utils.CucumberLogUtils;

public class StayFitStepsImpl {
	
	private StayFitFoodPage stayFitPage;
	
	public StayFitFoodPage getPage() {
		if (null == stayFitPage) {
			return PageFactory.initElements(ScenarioContext.webDriver.get(), StayFitFoodPage.class);
		}
		return stayFitPage;
	}
	
	public void navigateToFoodTab() {
		getPage().foodTab.click();
	}
	
	public void navigateToExerciseTab() throws Exception {
		Thread.sleep(3000);
		getPage().exerciseTab.click();
	}
	
	public void checkFieldsOnFoodTab() throws Exception {
		CucumberLogUtils.logPass("food Inputs Tab", true);
		if (!getPage().foodDateField.isDisplayed()) {
			Assert.fail("dateField is not displayed");
		} else if (!getPage().foodItem.isDisplayed()) {
			Assert.fail("foodItem is not displayed");
		} else if (!getPage().foodQuantity.isDisplayed()) {
			Assert.fail("foodQuantity is not displayed");
		}		
	}
	
	public void checkFieldsOnExerciseTab() throws Exception {
		CucumberLogUtils.logPass("Exercise Inputs Tab", true);
		if (!getPage().exerciseDate.isDisplayed()) {
			Assert.fail("dateField is not displayed");
		} else if (!getPage().exerciseItem.isDisplayed()) {
			Assert.fail("exercise type is not displayed");
		} else if (!getPage().exerciseDuration.isDisplayed()) {
			Assert.fail("exercise duration is not displayed");
		}		
	}
	
	public void enterFoodInformation(FoodVO foodInformation) throws Exception {
		Thread.sleep(2000);
		getPage().foodDateField.sendKeys(foodInformation.getDate());
		Select foodItemSelect = new Select(getPage().foodItem);
		foodItemSelect.selectByVisibleText(foodInformation.getName());
		Select foodQuantitySelect = new Select(getPage().foodQuantity);
		foodQuantitySelect.selectByVisibleText(foodInformation.getQuantity());
		CucumberLogUtils.logPass("food information provided", true);
	}
	
	public void clearFoodInformation() throws Exception {
		getPage().clearFood.click();
		WebElement confirmSave = ScenarioContext.webDriver.get().findElement(By.cssSelector("button[data-bb-handler='confirm']"));
		confirmSave.click();
		WebElement acknowledgeDeleted = ScenarioContext.webDriver.get().findElement(By.cssSelector("button[data-bb-handler='ok']"));
		acknowledgeDeleted.click();
		CucumberLogUtils.logPass("food information cleared", true);
	}
	
	public void validateFoodInformationIsDeleted() throws Exception {
		CucumberLogUtils.logPass("food information deleted -- confirmation", true);
	}
	
	public void saveFoodInformation() {
		getPage().saveFood.click();
		WebElement confirmSave = ScenarioContext.webDriver.get().findElement(By.cssSelector("button[data-bb-handler='confirm']"));
		confirmSave.click();
		WebElement acknowledgeSaved = ScenarioContext.webDriver.get().findElement(By.cssSelector("button[data-bb-handler='ok']"));
		acknowledgeSaved.click();
	}
	
	public void saveExerciseInformation() {
		JavascriptExecutor executor = (JavascriptExecutor) ScenarioContext.webDriver.get();
		executor.executeScript("arguments[0].click();", getPage().saveExercise);
		WebElement confirmSave = ScenarioContext.webDriver.get().findElement(By.cssSelector("button[data-bb-handler='confirm']"));
		executor.executeScript("arguments[0].click();", confirmSave);
		WebElement acknowledgeSaved = ScenarioContext.webDriver.get().findElement(By.cssSelector("button[data-bb-handler='ok']"));
		executor.executeScript("arguments[0].click();", acknowledgeSaved);
	}
	
	public void enterExerciseInformation(ExerciseVO exercise) throws Exception {
		Thread.sleep(2000);
		getPage().exerciseDate.sendKeys(exercise.getDate());
		Select exerciseDurationSelect = new Select(getPage().exerciseDuration);
		exerciseDurationSelect.selectByVisibleText(exercise.getDuration());
		Select exerciseType = new Select(getPage().exerciseItem);
		exerciseType.selectByVisibleText(exercise.getExercise());
		CucumberLogUtils.logPass("exercise information provided", true);
		Thread.sleep(2000);
		
	}
	
	public void clearExerciseInformation() throws Exception {
		JavascriptExecutor executor = (JavascriptExecutor) ScenarioContext.webDriver.get();
		executor.executeScript("arguments[0].click();", getPage().clearExercise);
		WebElement confirmSave = ScenarioContext.webDriver.get().findElement(By.cssSelector("button[data-bb-handler='confirm']"));
		executor.executeScript("arguments[0].click();", confirmSave);
		WebElement acknowledgeDeleted = ScenarioContext.webDriver.get().findElement(By.cssSelector("button[data-bb-handler='ok']"));
		executor.executeScript("arguments[0].click();", acknowledgeDeleted);
		CucumberLogUtils.logPass("exercise information cleared", true);
	}
	
	public void validateExerciseInformationIsDeleted() throws Exception {
		CucumberLogUtils.logPass("exercise information deleted -- confirmation", true);
	}
	
	public void validateReport(ReportVO report) throws Exception {
		JavascriptExecutor executor = (JavascriptExecutor) ScenarioContext.webDriver.get();
		executor.executeScript("arguments[0].click();", getPage().reportTab);
		List<WebElement> data = getPage().reportTableRow.findElements(By.tagName("td"));
		ReportVO actualReport = new ReportVO();
		actualReport.setDate(data.get(0).getText());
		actualReport.setCaloriesConsumed(data.get(1).getText());
		actualReport.setCaloriesBurnt(data.get(2).getText());
		actualReport.setNetCalories(data.get(3).getText());
		actualReport.setStatus(data.get(4).getText());
		boolean isSame = actualReport.isSame(report);
		if (!isSame) {
			Assert.fail("Report is not accurate");
		}
		CucumberLogUtils.logPass("report is generated", true);
	}
	
	public void clearInformation() throws Exception {
		Thread.sleep(3000);
		navigateToFoodTab();
		clearFoodInformation();
		navigateToExerciseTab();
		clearExerciseInformation();
	}
}
