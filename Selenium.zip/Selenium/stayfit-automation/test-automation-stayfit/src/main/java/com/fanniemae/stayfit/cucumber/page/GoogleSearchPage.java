package com.fanniemae.stayfit.cucumber.page;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;


public class GoogleSearchPage {
	
	
	@FindBy(how = How.NAME, using = "q")
	public WebElement searchBox;
	
	@FindBy(how = How.NAME, using = "btnK")
	public WebElement searchButton;
	
	@FindBy(how = How.NAME, using = "btnI")
	public WebElement feelingLuckyButton;
	
	@FindBy(how = How.NAME, using="gsri_ok0")
	public WebElement mic;

}
