package com.fanniemae.stayfit.cucumber.vo;

public class ReportVO {
	
	private String date;
	private String caloriesConsumed;
	private String caloriesBurnt;
	private String netCalories;
	private String status;
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getCaloriesConsumed() {
		return caloriesConsumed;
	}
	public void setCaloriesConsumed(String caloriesConsumed) {
		this.caloriesConsumed = caloriesConsumed;
	}
	public String getCaloriesBurnt() {
		return caloriesBurnt;
	}
	public void setCaloriesBurnt(String caloriesBurnt) {
		this.caloriesBurnt = caloriesBurnt;
	}
	public String getNetCalories() {
		return netCalories;
	}
	public void setNetCalories(String netCalories) {
		this.netCalories = netCalories;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public boolean isSame(ReportVO checkWith) {
		if (this.date.equalsIgnoreCase(checkWith.getDate())
				&& this.status.equalsIgnoreCase(checkWith.getStatus())
				&& this.caloriesBurnt.equalsIgnoreCase(checkWith.getCaloriesBurnt())
				&& this.caloriesConsumed.equalsIgnoreCase(checkWith.getCaloriesConsumed())
				&& this.netCalories.equalsIgnoreCase(checkWith.getNetCalories())) {
			return true;
		}
		return false;
	}
}
