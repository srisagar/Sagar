package com.fanniemae.stayfit.cucumber.stepDefs;

import com.fanniemae.stayfit.cucumber.impl.DemonstrationStepImpl;

import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DemonstrationStepDefs extends BaseStepDef {
	
	DemonstrationStepImpl demonstrationStepImpl = new DemonstrationStepImpl();

    @Given("^I am able to open the url \"([^\"]*)\"$")
    public void navigateToURL(String url) throws Exception {
        getFireFoxWebDriver().get(url);
    }

    @When("^I provide the phrase \"([^\"]*)\"$")
    public void searchForThePhrase(String searchPhrase) throws Exception {
    	demonstrationStepImpl.enterSearchPhrase(searchPhrase);
    }

    @Then("^I should be able to see the search results$")
    public void validateSearchResults() throws Exception {
        demonstrationStepImpl.validateSearchResults();
    }
    
}