/*
 * Copyright (c) [2014] Fannie Mae. All rights reserved.
 * 
 * Unpublished -- Rights reserved under the copyright laws of the United States
 * and international conventions. Use of a copyright notice is precautionary only
 * and does not imply publication or disclosure. This software contains confidential
 * information and trade secrets of Fannie Mae. Use, disclosure, or reproduction is
 * prohibited without the prior written consent of Fannie Mae.
 */
package com.fanniemae.stayfit.cucumber.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;

import com.fanniemae.testeng.automation.utils.CucumberLogUtils;
import com.fanniemae.testeng.automation.utils.LocalConfUtils;

/**
 *
 */
public class StayFitConfUtils {

    private static final String RUNNERS_PATH = "src" + File.separator +
                    "test" + File.separator + "java" + File.separator + "com" +
                    File.separator + "fanniemae" + File.separator + "stayfit" +
                    File.separator + "runners";

    private static final String RESOURCES_PATH = "src" + File.separator + "main"
            + File.separator + "resources";
    private static final String CONTENT_PATH = "src" + File.separator + "main"
            + File.separator + "resources";

    private static final String DATA_FILE_TO_UPLOAD_DIRECTORY = "dataFileToUploadDirectory";

    private static Properties localConf = null;
    private static String resultsDir = "";
    private static String baseResultsDir = "";

    private static final String LOCAL_LOG_DIR = "stayfitlogdir";

    private static Properties loadLocalConf() {
        localConf = LocalConfUtils.loadLocalConf();
        return localConf;
    }

    public static File getLocalLogDir() {
        String usrDir = System.getProperty("java.io.tmpdir");
        File localLogDir = new File(usrDir, LOCAL_LOG_DIR);

        return localLogDir;
    }

    public static Properties getProperties() {
        if (localConf == null) {
            loadLocalConf();
        }

        return localConf;
    }

    public static String getProperty(String key) {

        if (localConf == null) {
            loadLocalConf();
        }

        return localConf.getProperty(key);

    }

    private static String getRootDir() {
        return System.getProperty("user.dir");
    }

    public static String getResourcesDir() {
        return getRootDir() + File.separator + RESOURCES_PATH;
    }

    private static String getContentDir() {
        return getRootDir() + File.separator + CONTENT_PATH;
    }

    public static String getTempDir() {
        return getResourcesDir() + File.separator + "conf" +
                File.separator + "temp";
    }

    public static String getQcResourcesDir() {
        return getResourcesDir() + File.separator + "libs" + File.separator + "qc";
    }

    public static String getSitRunnersDir() {
        return getRootRunnersDir() + File.separator + "sit";
    }

    public static String getTempRunnersDir() {
        return getRootRunnersDir() + File.separator + "temp";
    }

    public static String getUatRunnersDir() {
        return getRootRunnersDir() + File.separator + "uat";
    }

    private static String getRootRunnersDir() {
        return getRootDir() + File.separator + RUNNERS_PATH;
    }

    public static String getDataDir() {

        return getContentDir() + File.separator + "data" + File.separator + getSuiteType();
    }

    public static String getFeaturesDir() {

        return getContentDir() + File.separator + "features" + File.separator + getSuiteType();
    }

    public static String getEnvironment()
    {
        /*
         * Check for command line parameter
         */
        String env = System.getProperty("env");
        if (StringUtils.isBlank(env))
        {
            env = getProperty("env");
        }
        return env;
    }
    
    public static String getEnvFileResourcePath() 
    {
        String env = getEnvironment();
        String envConfigFilePath = "/conf/env/" + env + ".xml";
        return envConfigFilePath;
    }

    public static String getUserFileResourcePath()
    {
        String userConfigFilePath = "/conf/users.xml";
        return userConfigFilePath;
    }

    public static String getSuiteType()
    {
        String suiteType = getProperty("suiteType");
        return StringUtils.isNotBlank(suiteType) ? suiteType : "sit";
    }

    /**
     * This method appends the output results dir with scenarioName.
     */
    public static String getResultsDir()
    {
        return resultsDir;
    }

    public static String getResultsDataDir() {

        String resultsDataDir = getResultsDir() + File.separator + "data";

        File dir = new File(resultsDataDir);
        if(!dir.exists()) dir.mkdirs();

        return resultsDataDir;

    }
    
    public static String getMismatchDataDir() {

        String resultsDataDir = getResultsDir() + File.separator + ".."+ File.separator +"MisMatchedReports";

        File dir = new File(resultsDataDir);
        if(!dir.exists()) dir.mkdirs();

        return resultsDataDir;

    }

    /**
     * This is just the name of the directory that is to be under
     * {@link LdngConfUtils#baseResultsDir}. Should not be complete dirpath
     */
    public static void setResultsDir(String resultsDirName)
    {
        StayFitConfUtils.resultsDir = StayFitConfUtils.baseResultsDir
                + File.separator + resultsDirName;
    }

    /**
     * Fully qualified base dirpath under which individual scenario related
     * directories will be created.
     */
    public static void setBaseResultsDir(String baseResultsDir) {
        StayFitConfUtils.baseResultsDir = baseResultsDir;
    }

    /**
     * Returns Fully qualified base dirpath under which individual scenario
     * related directories will be created.
     */
    public static String getBaseResultsDir() {
        return StayFitConfUtils.baseResultsDir;
    }
    
    public static String getWebDriverLibsDir() {
        return getResourcesDir(); 
    }

//    public static String getWebDriverLibsDir() {
//        return getResourcesDir() + File.separator + "libs" + File.separator + "webdriver";
//    }

    public static String getInputDataFileDirectory() {
        return LocalConfUtils.getProperty(DATA_FILE_TO_UPLOAD_DIRECTORY);
    }
    
    public synchronized static void appendFailedScenarios(String scenarioName) {

      File resultsDir = new File(getResultsDir());
      String buildDir = resultsDir.getParent();
      String failedDirStr = ".FailedScenarios";
      String failedScenarios = buildDir + File.separator + failedDirStr + File.separator +"_FailedScenarios.txt";
      File failedFilesList = new File(failedScenarios);
      try {
        if (!failedFilesList.exists()) {
          File failedDir = new File(buildDir + File.separator + failedDirStr);
          if(!failedDir.exists()) {
            failedDir.mkdir();
          }
          // Crete a new file if not created already
          failedFilesList.createNewFile();
        }
      } catch (IOException e) {
        e.printStackTrace();
        CucumberLogUtils.logError(e.getMessage());
      }

      try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(failedScenarios, true)))) {
        out.println(scenarioName);
      } catch (IOException e) {
        e.printStackTrace();
        CucumberLogUtils.logError(e.getMessage());
      }
    }
}