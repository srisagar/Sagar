package com.fanniemae.stayfit.cucumber.page;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BasePage {

	@FindBy(id="foodIcon")
	public WebElement foodTab;
	
	@FindBy(id="exerciseIcon")
	public WebElement exerciseTab;
	
	@FindBy(id="reportIcon")
	public WebElement reportTab;
}
