package com.fanniemae.stayfit.cucumber.impl;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.fanniemae.stayfit.cucumber.page.GoogleSearchPage;
import com.fanniemae.testeng.automation.common.ScenarioContext;
import com.fanniemae.testeng.automation.utils.CucumberLogUtils;

public class DemonstrationStepImpl {
	
	private GoogleSearchPage googleSearchPage;
	
	private GoogleSearchPage getPage() {
		if (null == googleSearchPage) {
			 return PageFactory.initElements(ScenarioContext.webDriver.get(), GoogleSearchPage.class);
		}
		return googleSearchPage;
	}
	
	public void enterSearchPhrase(String phrase) {
		getPage().searchBox.sendKeys(phrase);
	}
	
	public void validateSearchResults() throws Exception {
		WebDriverWait wait = new WebDriverWait(ScenarioContext.webDriver.get(), 5l);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("srg")));
		CucumberLogUtils.logInfo("google Search for selenium");
	}

}
