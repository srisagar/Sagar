package com.fanniemae.stayfit.cucumber;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;


@RunWith(Cucumber.class)
@CucumberOptions(
		plugin = { "com.fanniemae.testeng.automation.utils.AutomationHtmlFormatter:html-reports" },
		features="src/test/features",
		tags={"@stayFit"},
		glue = { "com.fanniemae.stayfit.cucumber.stepDefs" }
)
public class CucumberTest {

}
