formatter.scenario({
  "line": 5,
  "name": "Field Validation",
  "description": "",
  "id": "stay-fit-feature-to-record-food-and-exercise-information-and-generate-report-based-on-that.;field-validation",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 6,
  "name": "As a \"fitness freak\" I want to track my \"food\" habits",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "I should have option to record my food and exercise for a particular date",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "fitness freak",
      "offset": 6
    },
    {
      "val": "food",
      "offset": 41
    }
  ],
  "location": "StayFitStepDefs.validateFieldsOfFoodAndExercise(String,String)"
});
formatter.result({
  "duration": 407828399,
  "status": "passed"
});
formatter.match({
  "location": "StayFitStepDefs.checkFieldsOnFoodAndExerciseTabs()"
});
formatter.result({
  "duration": 6436601222,
  "error_message": "org.openqa.selenium.StaleElementReferenceException: Element not found in the cache - perhaps the page has changed since it was looked up\nCommand duration or timeout: 3.12 seconds\nFor documentation on this error, please visit: http://seleniumhq.org/exceptions/stale_element_reference.html\nBuild info: version: \u00272.52.0\u0027, revision: \u00274c2593cfc3689a7fcd7be52549167e5ccc93ad28\u0027, time: \u00272016-02-11 11:22:43\u0027\nSystem info: host: \u0027W81-PK1YTGT-U\u0027, ip: \u002710.128.170.209\u0027, os.name: \u0027Windows 8.1\u0027, os.arch: \u0027amd64\u0027, os.version: \u00276.3\u0027, java.version: \u00271.8.0_65\u0027\nDriver info: org.openqa.selenium.firefox.FirefoxDriver\nCapabilities [{applicationCacheEnabled\u003dtrue, rotatable\u003dfalse, handlesAlerts\u003dtrue, databaseEnabled\u003dtrue, version\u003d45.1.1, platform\u003dWINDOWS, nativeEvents\u003dfalse, acceptSslCerts\u003dtrue, webStorageEnabled\u003dtrue, locationContextEnabled\u003dtrue, browserName\u003dfirefox, takesScreenshot\u003dtrue, javascriptEnabled\u003dtrue, cssSelectorsEnabled\u003dtrue}]\nSession ID: 3c093039-b374-450f-8aa2-942272470266\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:422)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:206)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:158)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:678)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.execute(RemoteWebElement.java:327)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.isDisplayed(RemoteWebElement.java:368)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\r\n\tat java.lang.reflect.Method.invoke(Method.java:497)\r\n\tat org.openqa.selenium.support.pagefactory.internal.LocatingElementHandler.invoke(LocatingElementHandler.java:51)\r\n\tat com.sun.proxy.$Proxy15.isDisplayed(Unknown Source)\r\n\tat com.fanniemae.stayfit.cucumber.impl.StayFitStepsImpl.checkFieldsOnExerciseTab(StayFitStepsImpl.java:54)\r\n\tat com.fanniemae.stayfit.cucumber.stepDefs.StayFitStepDefs.checkFieldsOnFoodAndExerciseTabs(StayFitStepDefs.java:43)\r\n\tat ✽.Then I should have option to record my food and exercise for a particular date(stayFit.feature:7)\r\nCaused by: org.openqa.selenium.StaleElementReferenceException: Element not found in the cache - perhaps the page has changed since it was looked up\nFor documentation on this error, please visit: http://seleniumhq.org/exceptions/stale_element_reference.html\nBuild info: version: \u00272.52.0\u0027, revision: \u00274c2593cfc3689a7fcd7be52549167e5ccc93ad28\u0027, time: \u00272016-02-11 11:22:43\u0027\nSystem info: host: \u0027W81-PK1YTGT-U\u0027, ip: \u002710.128.170.209\u0027, os.name: \u0027Windows 8.1\u0027, os.arch: \u0027amd64\u0027, os.version: \u00276.3\u0027, java.version: \u00271.8.0_65\u0027\nDriver info: driver.version: unknown\r\n\tat \u003canonymous class\u003e.fxdriver.cache.getElementAt(resource://fxdriver/modules/web-element-cache.js:9407)\r\n\tat \u003canonymous class\u003e.Utils.getElementAt(file:///C:/Users/q2ugar/AppData/Local/Temp/anonymous8321718014845594848webdriver-profile/extensions/fxdriver@googlecode.com/components/command-processor.js:8992)\r\n\tat \u003canonymous class\u003e.WebElement.isElementDisplayed(file:///C:/Users/q2ugar/AppData/Local/Temp/anonymous8321718014845594848webdriver-profile/extensions/fxdriver@googlecode.com/components/command-processor.js:12142)\r\n\tat \u003canonymous class\u003e.DelayedCommand.prototype.executeInternal_/h(file:///C:/Users/q2ugar/AppData/Local/Temp/anonymous8321718014845594848webdriver-profile/extensions/fxdriver@googlecode.com/components/command-processor.js:12614)\r\n\tat \u003canonymous class\u003e.fxdriver.Timer.prototype.setTimeout/\u003c.notify(file:///C:/Users/q2ugar/AppData/Local/Temp/anonymous8321718014845594848webdriver-profile/extensions/fxdriver@googlecode.com/components/command-processor.js:623)\r\n",
  "status": "failed"
});
formatter.scenario({
  "line": 9,
  "name": "Clear Entered Food Data",
  "description": "",
  "id": "stay-fit-feature-to-record-food-and-exercise-information-and-generate-report-based-on-that.;clear-entered-food-data",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 10,
  "name": "As a \"fitness freak\" I want to track my \"food\" habits",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "I provide the food data and quantity for the corresponding date as :",
  "rows": [
    {
      "cells": [
        "date",
        "name",
        "quantity"
      ],
      "line": 12
    },
    {
      "cells": [
        "2016-01-01",
        "Daal",
        "1"
      ],
      "line": 13
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 14,
  "name": "I chose to clear the provided \"food\" data",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "all my \"food\" data gets deleted",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "fitness freak",
      "offset": 6
    },
    {
      "val": "food",
      "offset": 41
    }
  ],
  "location": "StayFitStepDefs.validateFieldsOfFoodAndExercise(String,String)"
});
formatter.result({
  "duration": 252539232,
  "status": "passed"
});
formatter.match({
  "location": "StayFitStepDefs.enterFoodInformation(FoodVO\u003e)"
});
formatter.result({
  "duration": 2458624108,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "food",
      "offset": 31
    }
  ],
  "location": "StayFitStepDefs.clearInformation(String)"
});
formatter.result({
  "duration": 742910864,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "food",
      "offset": 8
    }
  ],
  "location": "StayFitStepDefs.validteInformationIsDeleted(String)"
});
formatter.result({
  "duration": 109201,
  "status": "passed"
});
formatter.scenario({
  "line": 17,
  "name": "Clear Entered Excercise Data",
  "description": "",
  "id": "stay-fit-feature-to-record-food-and-exercise-information-and-generate-report-based-on-that.;clear-entered-excercise-data",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 18,
  "name": "As a \"fitness freak\" I want to track my \"exercise\" habits",
  "keyword": "Given "
});
formatter.step({
  "line": 19,
  "name": "I provide the exercise data and duration for the corresponding date as :",
  "rows": [
    {
      "cells": [
        "date",
        "exercise",
        "duration"
      ],
      "line": 20
    },
    {
      "cells": [
        "2016-01-01",
        "Abs",
        "15"
      ],
      "line": 21
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 22,
  "name": "I chose to clear the provided \"exercise\" data",
  "keyword": "And "
});
formatter.step({
  "line": 23,
  "name": "all my \"exercise\" data gets deleted",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "fitness freak",
      "offset": 6
    },
    {
      "val": "exercise",
      "offset": 41
    }
  ],
  "location": "StayFitStepDefs.validateFieldsOfFoodAndExercise(String,String)"
});
formatter.result({
  "duration": 3115903320,
  "status": "passed"
});
formatter.match({
  "location": "StayFitStepDefs.enterExerciseInformation(ExerciseVO\u003e)"
});
formatter.result({
  "duration": 7753936881,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "exercise",
      "offset": 31
    }
  ],
  "location": "StayFitStepDefs.clearInformation(String)"
});
formatter.result({
  "duration": 324649254,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "exercise",
      "offset": 8
    }
  ],
  "location": "StayFitStepDefs.validteInformationIsDeleted(String)"
});
formatter.result({
  "duration": 106737,
  "status": "passed"
});
formatter.scenario({
  "line": 25,
  "name": "Enter Food and Exercise data and check the report",
  "description": "",
  "id": "stay-fit-feature-to-record-food-and-exercise-information-and-generate-report-based-on-that.;enter-food-and-exercise-data-and-check-the-report",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 26,
  "name": "As a \"fitness freak\" I want to track my \"food and exercise\" habits",
  "keyword": "Given "
});
formatter.step({
  "line": 27,
  "name": "I provide the food data and quantity for the corresponding date as :",
  "rows": [
    {
      "cells": [
        "date",
        "name",
        "quantity"
      ],
      "line": 28
    },
    {
      "cells": [
        "2016-01-01",
        "Daal",
        "1"
      ],
      "line": 29
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 30,
  "name": "I choose to save the \"food\" data",
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "I provide the exercise data and duration for the corresponding date as :",
  "rows": [
    {
      "cells": [
        "date",
        "exercise",
        "duration"
      ],
      "line": 32
    },
    {
      "cells": [
        "2016-01-01",
        "Abs",
        "15"
      ],
      "line": 33
    }
  ],
  "keyword": "And "
});
formatter.step({
  "line": 34,
  "name": "I choose to save the \"exercise\" data",
  "keyword": "And "
});
formatter.step({
  "line": 35,
  "name": "I should be able to see my report with following details :",
  "rows": [
    {
      "cells": [
        "Date",
        "Calories Consumed",
        "Calories Burnt",
        "Net Calories",
        "Status"
      ],
      "line": 36
    },
    {
      "cells": [
        "2016-01-01",
        "264",
        "285",
        "-21",
        "You did it"
      ],
      "line": 37
    }
  ],
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "fitness freak",
      "offset": 6
    },
    {
      "val": "food and exercise",
      "offset": 41
    }
  ],
  "location": "StayFitStepDefs.validateFieldsOfFoodAndExercise(String,String)"
});
formatter.result({
  "duration": 170205368,
  "status": "passed"
});
formatter.match({
  "location": "StayFitStepDefs.enterFoodInformation(FoodVO\u003e)"
});
formatter.result({
  "duration": 2632110432,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "food",
      "offset": 22
    }
  ],
  "location": "StayFitStepDefs.saveInformation(String)"
});
formatter.result({
  "duration": 1917276544,
  "status": "passed"
});
formatter.match({
  "location": "StayFitStepDefs.enterExerciseInformation(ExerciseVO\u003e)"
});
formatter.result({
  "duration": 7902854210,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "exercise",
      "offset": 22
    }
  ],
  "location": "StayFitStepDefs.saveInformation(String)"
});
formatter.result({
  "duration": 727919126,
  "status": "passed"
});
formatter.match({
  "location": "StayFitStepDefs.validateReport(ReportVO\u003e)"
});
formatter.result({
  "duration": 325494124,
  "status": "passed"
});
